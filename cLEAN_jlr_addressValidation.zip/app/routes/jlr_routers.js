var path = require('path');
const { check } = require('express-validator');
const serviceCtrl = require(path.join(__dirname, '..', 'controllers', 'serviceCtrl.controller'));

module.exports = (app, upload) => {
    var default_url_path = '/api/jlrservices/'
    app.post(`${default_url_path}jlrAddressValidator`, serviceCtrl.addressValidator);
}
