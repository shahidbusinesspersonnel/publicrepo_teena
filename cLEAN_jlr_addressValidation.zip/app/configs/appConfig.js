let config = {};

// config.port = 3333;
config.port = 3334;
config.GOOGLE_API_KEY = '*************************';
config.PLACE_API_ENDPOINT ='https://maps.googleapis.com/maps/api/place/findplacefromtext/';
config.ENV ='DEV';

module.exports = config;
